

function Navbar() {
   return (
      <nav>
         
         
         <span>StudyFlow</span>
      </nav>
   );
}

function Banner() {
   return <section />;
}

function App() {
 

  return (
     <div>
        <Navbar />
        <Banner />
        <stats />
        
        
     </div>
  )
}

export default App
