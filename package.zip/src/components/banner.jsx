const banner = () => {
    return (
        <div className="container mx-auto text-center py-[45px] space-y-16"> 
            <span className="badge">Built for students who like to see progress</span>
             <h2 className="font-semibold text-5xl max-w-[700px] mx-auto ">
             Turn big goals into daily tacks you'll actually finish </h2>
        <p className="max-w-[700px] mx-auto ">
          set a goal break it into taks , and watch a progress a bar move every time you check one off, no spreadsheet, no guessing what o study next

        </p>

        <div className="flex gap-2 items-center justify-center mt-4">
          
          <button className="btn btn-soft btn-success text-white border-none">Get Started</button>
           <button className="btn btn-soft btn-success">See How It Works</button>
        </div>

        <div className="card bg-base-100 w-[550px] mx-auto shadow-sm space-y-4 text-black">
            <div className="flex justify-between items-center gap-4">
             <h2 className="font-bold text-2xl">Today's Progress</h2>
              <p>50% complete</p>             

            </div>

          <progress className="progress text-primary h-[15PX]" value="100" max="100"></progress>  
            
       <ul className="space-y-5">
           <li className="flex  items-center gap-4 border border-[#0e7c66] rounded-md p-2" >
                solve 5 questions from math
           </li>

            <li className="flex items-center gap-4 border border-[#0e7c66] rounded-md p-2" >
                read 20 pages of history
           </li>
            <li className="flex  items-center gap-4 border border-[#0e7c66] rounded-md p-2" >
                write a journal entry
           </li>


        </ul>   

      
  </div>
</div>
    );
};

export default banner;