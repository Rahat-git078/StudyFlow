
import { LuNotebookPen } from "react-icons/lu";

const Navbar = () => {
     
    return (
        
        <div className="bg-[#f0f1eb]">
             <nav className="flex justify-between gap-4 items-center py-4  container mx-auto">
                <span><LuNotebookPen className="text-[#0e7c66] h-[35px] w-[35px]" /> </span>
                 <ul  className="flex gap-2 items-center text-slate-700">
        
                  <li><a href="/">Features</a></li>
                  <li><a href="/about">How It works</a></li>
                  <li><a href="/contact">pricing</a></li>
                  <li><a href="/contact">FAQ</a></li>
                  
                  
                </ul>
        
                   <div>
                        <button className=" text-white px-4 py-2 rounded-md semi-bold text-xl">login</button>
                        <button className="bg-[#0e7c66] text-white px-4 py-2 rounded-md hover:bg-[#0a5d4d]"> Get started </button>
        
                   </div>
        
             </nav>
        
            </div>

    )

}

export default Navbar;